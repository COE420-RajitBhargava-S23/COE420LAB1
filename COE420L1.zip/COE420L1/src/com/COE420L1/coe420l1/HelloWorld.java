package com.COE420L1.coe420l1;

public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("Hello World");
	}

}





